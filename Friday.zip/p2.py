#Implement a model-based intelligent agent that navigates a grid environment with obstacles using an internal state representation.

grid = [
    ['S', '.', '#'],
    ['.', '.', '#'],
    ['#', '.', 'G']
]

start = (0, 0)
goal = (2, 2)

# Internal state of the agent
visited = []
stack = [(start, [start])]

while stack:
    current, path = stack.pop()

    if current in visited:
        continue

    visited.append(current)

    if current == goal:
        print("Goal Reached!")
        print("Path:", path)
        break

    row, col = current

    # Possible movements: Up, Down, Left, Right
    moves = [
        (row-1, col),
        (row+1, col),
        (row, col-1),
        (row, col+1)
    ]

    for r, c in moves:
        if (0 <= r < 3 and 0 <= c < 3 and
            grid[r][c] != '#' and (r, c) not in visited):
            stack.append(((r, c), path + [(r, c)]))

else:
    print("Goal not found")


