# Design a Python program using BFS to find a path for a robot from a starting position to a goal position in a grid containing obstacles.

from collections import deque

grid = [
    ['S', '.', '#'],
    ['.', '.', '#'],
    ['#', '.', 'G']
]

start = (0, 0)
goal = (2, 2)

queue = deque([(start, [start])])
visited = {start}

while queue:

    current, path = queue.popleft()

    if current == goal:
        print("Goal Reached!")
        print("Path:", path)
        break

    row, col = current

    moves = [
        (row-1, col),
        (row+1, col),
        (row, col-1),
        (row, col+1)
    ]

    for r, c in moves:

        if (0 <= r < 3 and 0 <= c < 3 and
            grid[r][c] != '#' and (r, c) not in visited):

            visited.add((r, c))
            queue.append(((r, c), path + [(r, c)]))

else:
    print("Goal not found")